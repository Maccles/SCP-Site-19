# SCP-CB-Toolset

[Discord for my tools](https://discord.gg/Z2qHv2XffF)

Please consider supporting me on KoFi at the following link.

https://ko-fi.com/general101

## Toolset Description
A Blender addon for 5.0+ that allows for the following
* Import and export RMESH files for the original release of SCP Containment Breach and UER 1.5.6
* Import and export rigid X files for the original release of SCP Containment Breach
* Import and export B3D files for the original release of SCP Containment Breach and UER
* Import SMF files from 3D World Studio
* Import 3DW files from 3D World Studio. This is limited and is only to add lights culled by CBRE

## Credits

 * Joric
   * For making the b3d import script used during the object import process.
   * [io_scene_b3d](https://github.com/joric/io_scene_b3d)

 * Starman12976/Simoxus
   * For making the rmesh import script used as reference.
   * [RoomMeshImportExport](https://github.com/Starman12976/RoomMeshImportExport)
   
 * Kusaanko
   * For making the X import script used to handle model files for the original scp cb game that is used as reference.
   * [XFileSupport_for_BVE](https://github.com/kusaanko/XFileSupport_for_BVE)

 * Discord user General_101
   * Getting the ball rolling I guess?
